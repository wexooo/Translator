// Supported languages
const LANGUAGES = [
  { code: "en", name: "English" },
  { code: "tr", name: "Turkish" },
  { code: "de", name: "German" },
  { code: "fr", name: "French" },
  { code: "es", name: "Spanish" },
  { code: "it", name: "Italian" },
  { code: "pt", name: "Portuguese" },
  { code: "nl", name: "Dutch" },
  { code: "ru", name: "Russian" },
  { code: "ja", name: "Japanese" },
  { code: "ko", name: "Korean" },
  { code: "zh-CN", name: "Chinese" },
  { code: "ar", name: "Arabic" },
  { code: "hi", name: "Hindi" }
];

// Build the menu
browser.contextMenus.removeAll().then(() => {
  browser.contextMenus.create({
    id: "translate-main",
    title: "🌍 Translate Selection",
    contexts: ["selection"]
  });

  for (const lang of LANGUAGES) {
    browser.contextMenus.create({
      id: `translate-${lang.code}`,
      parentId: "translate-main",
      title: lang.name,
      contexts: ["selection"]
    });
  }
});

// When a language is clicked
browser.contextMenus.onClicked.addListener(async (info, tab) => {
  const id = String(info.menuItemId);
  if (!id.startsWith("translate-") || id === "translate-main") return;

  const targetLang = id.replace("translate-", "");
  const text = (info.selectionText || "").trim();
  if (!text) return;

  try {
    const translated = await translate(text, targetLang);
    const langName = LANGUAGES.find(l => l.code === targetLang)?.name || targetLang;

    const message = {
      type: "translation-result",
      source: text,
      result: translated,
      langName: langName
    };

    try {
      await browser.tabs.sendMessage(tab.id, message);
    } catch (e) {
      try {
        await browser.tabs.executeScript(tab.id, { file: "content.js" });
        await browser.tabs.insertCSS(tab.id, { file: "panel.css" });
        await browser.tabs.sendMessage(tab.id, message);
      } catch (e2) {
        browser.notifications.create({
          type: "basic",
          title: `🌍 Translated to ${langName}`,
          message: translated
        });
      }
    }
  } catch (err) {
    console.error("All translation engines failed:", err);
    browser.notifications.create({
      type: "basic",
      title: "❌ Translation failed",
      message: "No translation service could be reached. Check your connection."
    });
  }
});

// ---------- TRANSLATION WITH FALLBACK ENGINES ----------

async function translate(text, targetLang) {
  const engines = [
    { name: "Google", fn: translateWithGoogle },
    { name: "Lingva", fn: translateWithLingva },
    { name: "MyMemory", fn: translateWithMyMemory }
  ];

  let lastError = null;
  for (const engine of engines) {
    try {
      const result = await engine.fn(text, targetLang);
      if (result && result.trim()) {
        console.log(`Translated via ${engine.name}`);
        return result;
      }
    } catch (err) {
      console.warn(`${engine.name} failed:`, err);
      lastError = err;
    }
  }
  throw lastError || new Error("All engines failed");
}

// Engine 1: Google (free endpoint)
async function translateWithGoogle(text, targetLang) {
  const url =
    "https://translate.googleapis.com/translate_a/single" +
    `?client=gtx&sl=auto&tl=${targetLang}&dt=t&q=${encodeURIComponent(text)}`;

  const res = await fetch(url);
  if (!res.ok) throw new Error(`Google HTTP ${res.status}`);

  const data = await res.json();
  return data[0].map(part => part[0]).join("");
}

// Engine 2: Lingva (Google mirror, multiple instances)
async function translateWithLingva(text, targetLang) {
  const instances = [
    "https://lingva.ml",
    "https://lingva.lunar.icu",
    "https://translate.plausibility.cloud"
  ];

  let lastError = null;
  for (const base of instances) {
    try {
      const url = `${base}/api/v1/auto/${targetLang}/${encodeURIComponent(text)}`;
      const res = await fetch(url);
      if (!res.ok) throw new Error(`Lingva HTTP ${res.status}`);
      const data = await res.json();
      if (data.translation) return data.translation;
    } catch (err) {
      lastError = err;
    }
  }
  throw lastError || new Error("Lingva failed");
}

// Engine 3: MyMemory (guesses source as English)
async function translateWithMyMemory(text, targetLang) {
  const source = targetLang === "en" ? "tr" : "en";
  const url =
    "https://api.mymemory.translated.net/get" +
    `?q=${encodeURIComponent(text)}&langpair=${source}|${targetLang}`;

  const res = await fetch(url);
  if (!res.ok) throw new Error(`MyMemory HTTP ${res.status}`);

  const data = await res.json();
  if (data.responseStatus !== 200) throw new Error("MyMemory error");
  return data.responseData.translatedText;
}