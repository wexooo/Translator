// Prevent duplicate listeners when injected multiple times
if (!window.__zenTranslateLoaded) {
  window.__zenTranslateLoaded = true;

  browser.runtime.onMessage.addListener((msg) => {
    if (msg.type === "translation-result") {
      showPanel(msg);
    }
  });
}

function showPanel(msg) {
  const old = document.getElementById("zen-translate-panel");
  if (old) old.remove();

  const panel = document.createElement("div");
  panel.id = "zen-translate-panel";

  const header = document.createElement("div");
  header.className = "ztp-header";

  const title = document.createElement("span");
  title.textContent = `🌍 Translated to ${msg.langName}`;

  const closeBtn = document.createElement("button");
  closeBtn.textContent = "✕";
  closeBtn.onclick = () => panel.remove();

  header.appendChild(title);
  header.appendChild(closeBtn);

  const source = document.createElement("div");
  source.className = "ztp-source";
  source.textContent = msg.source;

  const arrow = document.createElement("div");
  arrow.className = "ztp-arrow";
  arrow.textContent = "↓";

  const result = document.createElement("div");
  result.className = "ztp-result";
  result.textContent = msg.result;

  const copyBtn = document.createElement("button");
  copyBtn.className = "ztp-copy";
  copyBtn.textContent = "📋 Copy";
  copyBtn.onclick = () => {
    navigator.clipboard.writeText(msg.result).then(() => {
      copyBtn.textContent = "✅ Copied!";
      setTimeout(() => (copyBtn.textContent = "📋 Copy"), 1500);
    });
  };

  panel.appendChild(header);
  panel.appendChild(source);
  panel.appendChild(arrow);
  panel.appendChild(result);
  panel.appendChild(copyBtn);

  document.body.appendChild(panel);
}